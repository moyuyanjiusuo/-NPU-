import wave
import pyaudio
import json
import os
import threading
from vosk import Model, KaldiRecognizer

# ---------- 盲文字典（保持不变） ----------
braille_dict = {
    "服药之后会头晕恶心吗": "1,2,3,4 1,2,4,6 1,2,3,4 1,2,3,4",
    "无障碍挂号窗口在哪": "1,3,1,2,3,4 1,2,4,5 1,2,3,4",
    "叫号声音可以调大一点吗": "1,2,3,4 1,2,4,6 1,2,3,4",
    "ATM机的盲文按键怎么操作": "1,2,3,4 1,2,4,6 1,2,3,4",
    "办理业务单据麻烦逐行读给我签字": "1,2,3,4 1,2,4,6 1,2,3,4",
    "残疾人补贴办理流程是什么": "1,2,4,5 1,2,3,4 1,2,3,4",
    "低视力康复训练在哪里报名": "1,2,3,4 1,2,4,6 1,2,3,4",
    "盲文图书可以免费借阅吗": "1,3,4 1,2,3,4 1,2,3,4",
    "麻烦您慢一点说": "1,2,3 1,2,4,6 1,2,4 1,2,3 1,2,3",
    "非常感谢您的帮助": "1,2,4,5 1,2,3,4 1,2,3 1,2,4,6",
    "不用大声，正常音量就可以": "1,2,3,5 1,2,3,4 1,2,3 1,2,4,6",
    "请不要用手指，用语言描述位置": "1,2,3 1,2,3,4 1,2,3",
    "前方有危险，请及时提醒我": "1,2,3,4 1,2,4,6 1,2,3,4",
    "耽误您几分钟，不好意思": "1,2,3,4 1,2,4,6 1,2,3 1,2,3",
    "物品递给我时放在我手边": "1,2,3,4 1,2,4,6 1,2,3 1,2,3",
    "转弯、台阶提前和我说": "1,2,3,4 1,2,4,6 1,2,3 1,2,3",
    "我记不住方位，麻烦重复一遍路线": "1,3,4 1,2,3,4 1,2,4,6",
    "如果不方便，没关系，我自己慢慢摸索": "1,2,3,5 1,2,3,4",
    "不要突然碰我，会吓到我": "1,2,3,5 1,2,3,4",
    "不要突然抢走我的盲杖": "1,2,3,5 1,2,3,4",
    "请勿投喂、抚摸我的导盲犬": "1,2,3,5 1,2,3,4",
    "不要占用盲道，会阻碍出行": "1,2,3,5 1,2,3,4",
    "过马路不要猛地拉扯我前行": "1,2,3,5 1,2,3,4",

    # 短词/核心词
    "盲文": "1,3,4 1,2,3,4",
    "导盲犬": "1,2,4,5 1,3,4 1,2,5,6",
    "盲道": "1,3,4 1,2,4",
    "读屏": "1,4,5,1,3,2 1,2,3,4,1,3,4,6,2",
    "无障碍": "1,3 1,2,3,4 1,2,4,5",
    "坡道": "1,2,3,4 1,2,4,6",
    "斑马线": "1,2,3,4 1,2,4,5 1,2,3"
}
    # ... 保持原内容不变 ...


class AudioRecognizer:
    """语音识别与盲文转换控制器"""
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 16000
    CHUNK = 1024

    def __init__(self, wav_save_path="/home/elf/temp_record.wav",
                 model_folder="/home/elf/PycharmProjects/PythonProject/vosk-model-small-cn-0.22",
                 mic_id=None):
        """
        :param wav_save_path: 录音保存路径
        :param model_folder: Vosk 模型文件夹路径
        :param mic_id: 麦克风设备ID，None表示默认
        """
        self.wav_path = wav_save_path
        self.model_folder = model_folder
        self.mic_id = mic_id
        self.is_recording = False
        self.audio_frames = []
        self.record_lock = threading.Lock()
        self.pa = None
        self.stream = None

    @staticmethod
    def list_microphones():
        """打印所有麦克风设备ID（静态方法）"""
        try:
            p = pyaudio.PyAudio()
            print("\n========== 本机麦克风设备列表 ==========")
            for dev_id in range(p.get_device_count()):
                dev_info = p.get_device_info_by_index(dev_id)
                if dev_info["maxInputChannels"] > 0:
                    print(f"设备ID: {dev_id} | 名称: {dev_info['name']}")
            p.terminate()
        except Exception as e:
            print(f"\n⚠️ 读取声卡失败: {e}")

    def start_recording(self):
        """启动录音（在后台线程中运行）"""
        with self.record_lock:
            if self.is_recording:
                return
            self.is_recording = True
        threading.Thread(target=self._record_loop, daemon=True).start()

    def _record_loop(self):
        """录音循环（内部使用）"""
        try:
            self.pa = pyaudio.PyAudio()
            self.stream = self.pa.open(
                format=self.FORMAT,
                channels=self.CHANNELS,
                rate=self.RATE,
                input=True,
                frames_per_buffer=self.CHUNK,
                input_device_index=self.mic_id
            )
            self.audio_frames.clear()
            print("录音中...")
            while True:
                with self.record_lock:
                    if not self.is_recording:
                        break
                self.audio_frames.append(self.stream.read(self.CHUNK, exception_on_overflow=False))
            self.stream.stop_stream()
            self.stream.close()
            sampwidth = self.pa.get_sample_size(self.FORMAT)
            self.pa.terminate()
            # 保存为WAV
            wf = wave.open(self.wav_path, "wb")
            wf.setnchannels(self.CHANNELS)
            wf.setsampwidth(sampwidth)
            wf.setframerate(self.RATE)
            wf.writeframes(b"".join(self.audio_frames))
            wf.close()
            print("录音保存成功")
        except Exception as e:
            print(f"录音出错: {e}")
            with self.record_lock:
                self.is_recording = False

    def stop_recording(self):
        """停止录音（线程安全）"""
        with self.record_lock:
            self.is_recording = False

    def recognize(self):
        """识别录音文件，返回文字"""
        if not os.path.isdir(self.model_folder):
            print(f"【严重错误】Vosk模型文件夹不存在: {self.model_folder}")
            return f"模型文件夹不存在: {self.model_folder}"
        if not os.path.exists(self.wav_path):
            return "未检测到录音文件，请先录制音频"

        try:
            wf = wave.open(self.wav_path, "rb")
            total_frames = wf.getnframes()
            wf.close()
            if total_frames == 0:
                print("【警告】录音为空，麦克风没采集到声音！")
                return "录音为空，未采集到声音！"

            print("开始调用 Vosk 模型进行识别...")
            model = Model(self.model_folder)
            rec = KaldiRecognizer(model, self.RATE)
            rec.SetWords(True)

            wf = wave.open(self.wav_path, "rb")
            while True:
                chunk = wf.readframes(self.CHUNK)
                if len(chunk) == 0:
                    break
                rec.AcceptWaveform(chunk)
            result_json = json.loads(rec.FinalResult())
            result_text = result_json.get("text", "")
            if result_text:
                print(f"✅ 识别成功，结果: {result_text}")
            else:
                print("⚠️ 识别完成，但未识别出文字。")
            return result_text if result_text else "无识别内容（请大声说普通话）"
        except Exception as e:
            print(f"❌ 识别异常: {e}")
            return f"识别出错: {e}"

    def play_recording(self):
        """播放录音文件（后台线程）"""
        if not os.path.exists(self.wav_path):
            return
        def _play():
            wf = wave.open(self.wav_path, 'rb')
            p = pyaudio.PyAudio()
            s = p.open(
                format=p.get_format_from_width(wf.getsampwidth()),
                channels=wf.getnchannels(),
                rate=wf.getframerate(),
                output=True
            )
            data = wf.readframes(self.CHUNK)
            while data:
                s.write(data)
                data = wf.readframes(self.CHUNK)
            s.stop_stream()
            s.close()
            p.terminate()
            wf.close()
        threading.Thread(target=_play, daemon=True).start()

    @staticmethod
    def text_to_braille(text):
        """静态方法：文字转盲文点位编码（与之前逻辑相同）"""
        sorted_keys = sorted(braille_dict.keys(), key=len, reverse=True)
        buf = []
        i = 0
        while i < len(text):
            matched = False
            for key in sorted_keys:
                if text[i:i+len(key)] == key:
                    buf.append(braille_dict[key])
                    i += len(key)
                    matched = True
                    break
            if not matched:
                buf.append(braille_dict.get(text[i], f"[{text[i]}]"))
                i += 1
        return " | ".join(buf)

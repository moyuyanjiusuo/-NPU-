#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盲文学习模式 —— 通过串口 UART 逐个输出声母和韵母的盲文点形
支持：
  1. 逐个显示所有声母
  2. 逐个显示所有韵母
  3. 全部顺序显示（声母 + 韵母）
"""

import time
import sys
# import gpiod
# from gpiod.line import Direction, Value
import serial

# ===================== 盲文对照表 =====================
pinyin_to_binary = {
    # 复合韵母
    "ong": "110010", "weng": "110010",
    "yuan": "101111", "üan": "101111",
    "yun": "111000", "ün": "111000",
    "yong": "111001", "iang": "111001",
    # 声母
    "b": "000011",
    "p": "001111",
    "m": "001101",
    "f": "001011",
    "d": "011001",
    "t": "011110",
    "n": "011101",
    "l": "000111",
    "g": "011011", "j": "011011",
    "k": "000101", "q": "000101",
    "h": "010011", "x": "010011",
    "zhi": "001100", "zh": "001100",
    "chi": "011111", "ch": "011111",
    "shi": "110001", "sh": "110001",
    "r": "010110", "ri": "010110",
    "z": "110101", "zi": "110101",
    "c": "001001", "ci": "001001",
    "s": "001110", "si": "001110",
    # 单韵母
    "a": "010100",
    "o": "100010", "e": "100010",
    "yi": "001010", "i": "001010",
    "wu": "100101", "u": "100101",
    "yu": "101100", "ü": "101100",
    "er": "010111",
    # 复韵母
    "ai": "101010",
    "ao": "101110",
    "ei": "101110",
    "ou": "110111",
    "ya": "101011", "ia": "101011",
    "yao": "011100", "iao": "011100",
    "ye": "010001", "ie": "010001",
    "you": "110011", "iou": "110011",
    "wa": "111111", "ua": "111111",
    "wai": "111101", "uai": "111101",
    "wei": "111010", "uei": "111010",
    "wo": "010101", "uo": "010101",
    "yue": "111110", "üe": "111110",
    # 鼻韵母
    "an": "100111",
    "en": "110100",
    "ang": "100110",
    "eng": "111100",
    "yan": "101001", "ian": "101001",
    "yang": "101101", "iang_y": "101101",
    "yin": "100011", "in": "100011",
    "ying": "100001", "ing": "100001",
    "uan": "111011", "wan": "111011",
    "uang": "110110", "wang": "110110",
    "uen": "010010", "wen": "010010",
    "ui": "010111", "iu": "110011",
}

initials = ["zh", "ch", "sh", "b", "p", "m", "f", "d", "t", "n", "l",
            "g", "k", "h", "j", "q", "x", "z", "c", "s", "r"]

# 所有韵母（去重，去掉 iang_y 这种辅助键）
finals = [
    "a", "o", "e", "i", "u", "ü", "er",
    "ai", "ei", "ao", "ou",
    "yi", "wu", "yu",
    "ya", "ye", "yao", "you", "yan", "yin", "yang", "ying", "yuan", "yun",
    "ia", "ie", "iao", "iou", "ian", "in", "iang", "ing", "üan", "ün", "üe",
    "wa", "wo", "wai", "wei", "wan", "wen", "wang", "weng", "uang",
    "an", "en", "ang", "eng",
    "uan", "uen", "uang",
    "ong", "yong",
    "ui", "iu",
]

# 去重并保持顺序
_seen = set()
finals_unique = []
for f in finals:
    if f not in _seen and f in pinyin_to_binary:
        _seen.add(f)
        finals_unique.append(f)
finals = finals_unique

# ===================== GPIO 配置（已注释，改用串口） =====================
# _CHIP_PATH = "/dev/gpiochip3"
# _PIN_OFFSETS = {
#     109: 13,   # DS
#     108: 12,   # STCP
#     98:  2,    # SHCP
# }
# _DS_PIN = 109
# _STCP_PIN = 108
# _SHCP_PIN = 98
#
# _gpio_req = None
#
#
# def _setup_gpio():
#     global _gpio_req
#     config = {}
#     for abs_pin, offset in _PIN_OFFSETS.items():
#         config[offset] = gpiod.LineSettings(
#             direction=Direction.OUTPUT,
#             output_value=Value.INACTIVE
#         )
#     try:
#         _gpio_req = gpiod.request_lines(
#             _CHIP_PATH,
#             consumer="braille_learn",
#             config=config
#         )
#     except Exception as e:
#         raise RuntimeError(f"GPIO 请求失败: {e}")
#
#
# def _cleanup_gpio():
#     global _gpio_req
#     if _gpio_req:
#         _gpio_req.release()
#         _gpio_req = None
#
#
# def _gpio_write(pin, value):
#     offset = _PIN_OFFSETS.get(pin)
#     if offset is None:
#         raise ValueError(f"未知引脚编号: {pin}")
#     _gpio_req.set_value(offset, Value.ACTIVE if value else Value.INACTIVE)
#
#
# def _send_single_braille_595(decimal_value, cell=0):
#     """
#     发送单个盲文字符（1个字节）到74HC595
#     decimal_value: 要显示的盲文点形数据
#     cell: 显示位置，0=第一个方，1=第二个方，其余补0（空白）
#     """
#     bytes_list = [0] * 8
#     if 0 <= cell < 8:
#         bytes_list[cell] = decimal_value
#     _gpio_write(_STCP_PIN, 0)
#     for byte in reversed(bytes_list):
#         for i in range(7, -1, -1):
#             bit = 1 - ((byte >> i) & 1)  # 低电平有效，取反
#             _gpio_write(_DS_PIN, bit)
#             _gpio_write(_SHCP_PIN, 1)
#             time.sleep(0.000001)
#             _gpio_write(_SHCP_PIN, 0)
#     _gpio_write(_STCP_PIN, 1)
#     time.sleep(0.000001)
#     _gpio_write(_STCP_PIN, 0)


# ===================== 串口配置（UART） =====================
UART_PORT = '/dev/ttyS9'
UART_BAUDRATE = 9600
UART_TIMEOUT = 1

_ser = None


def _open_uart():
    """打开串口"""
    global _ser
    if _ser is not None and _ser.is_open:
        return
    try:
        _ser = serial.Serial(
            port=UART_PORT,
            baudrate=UART_BAUDRATE,
            bytesize=serial.EIGHTBITS,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            timeout=UART_TIMEOUT
        )
        print(f"串口 {UART_PORT} 已打开 (波特率={UART_BAUDRATE})")
    except Exception as e:
        print(f"串口打开失败: {e}")
        raise RuntimeError(f"串口打开失败: {e}")


def _close_uart():
    """关闭串口"""
    global _ser
    if _ser is not None and _ser.is_open:
        _ser.close()
        _ser = None
        print("串口已关闭")


def _send_single_braille(decimal_value, cell=0):
    """
    通过串口发送单个盲文字符（8字节，只有一个方有数据，其余为0）
    decimal_value: 要显示的盲文点形数据
    cell: 显示位置，0=第一个方，1=第二个方，其余补0（空白）
    """
    _open_uart()
    bytes_list = [0] * 8
    if 0 <= cell < 8:
        bytes_list[cell] = decimal_value
    data = bytes(bytes_list)
    _ser.write(data)
    hex_str = ' '.join(f'0x{b:02X}' for b in data)
    print(f"串口已发送: {hex_str}")


def _send_text_uart(text):
    """通过串口发送拼音文本"""
    _open_uart()
    data = (text + '\n').encode('utf-8')
    _ser.write(data)
    print(f"串口已发送文本: {text}")


def _clear_display():
    """清空盲文显示"""
    _send_single_braille(0)


def _binary_to_dots(binary_str):
    """将6位二进制字符串转为盲文点形可视化（用●和○表示）"""
    dots = ""
    for ch in binary_str:
        dots += "●" if ch == "1" else "○"
    return dots


# ===================== 学习模式 =====================

def learn_initials(delay=2.0):
    """
    学习声母模式
    逐个显示所有声母的盲文点形
    delay: 每个声母停留时间（秒）
    """
    print("=" * 50)
    print("【声母学习模式】")
    print(f"共 {len(initials)} 个声母，每个停留 {delay} 秒")
    print("按 Ctrl+C 提前退出")
    print("=" * 50)

    _open_uart()
    try:
        for idx, init in enumerate(initials, 1):
            binary = pinyin_to_binary[init]
            decimal = int(binary, 2)
            dots = _binary_to_dots(binary)

            print(f"[{idx:2d}/{len(initials)}] 声母: {init:4s}  "
                  f"二进制: {binary}  点形: {dots}  十进制: {decimal}")

            # 发送拼音文本 + 盲文字节
            _send_text_uart(init)
            _send_single_braille(decimal)
            time.sleep(delay)

        print("\n声母学习完毕！")
        _clear_display()
    except KeyboardInterrupt:
        print("\n\n用户中断，正在退出...")
        _clear_display()
    finally:
        _close_uart()


def learn_finals(delay=8.0):
    """
    学习韵母模式
    逐个显示所有韵母的盲文点形（显示在第二个方）
    delay: 每个韵母停留时间（秒）
    """
    print("=" * 50)
    print("【韵母学习模式】")
    print(f"共 {len(finals)} 个韵母，每个停留 {delay} 秒")
    print("按 Ctrl+C 提前退出")
    print("=" * 50)

    _open_uart()
    try:
        for idx, final in enumerate(finals, 1):
            binary = pinyin_to_binary[final]
            decimal = int(binary, 2)
            dots = _binary_to_dots(binary)

            print(f"[{idx:2d}/{len(finals)}] 韵母: {final:5s}  "
                  f"二进制: {binary}  点形: {dots}  十进制: {decimal}")

            # 发送拼音文本 + 盲文字节（韵母在第二个方）
            _send_text_uart(final)
            _send_single_braille(decimal, cell=1)
            time.sleep(delay)

        print("\n韵母学习完毕！")
        _clear_display()
    except KeyboardInterrupt:
        print("\n\n用户中断，正在退出...")
        _clear_display()
    finally:
        _close_uart()


def learn_all(delay=8.0):
    """
    完整学习模式：先声母，后韵母
    声母显示在第一个方，韵母显示在第二个方
    """
    print("=" * 50)
    print("【完整盲文学习模式】")
    print(f"声母 {len(initials)} 个 + 韵母 {len(finals)} 个")
    print(f"每个停留 {delay} 秒，按 Ctrl+C 提前退出")
    print("=" * 50)

    _open_uart()
    try:
        # 先显示声母（第一个方）
        print("\n--- 声母部分 ---")
        for idx, init in enumerate(initials, 1):
            binary = pinyin_to_binary[init]
            decimal = int(binary, 2)
            dots = _binary_to_dots(binary)

            print(f"[声母 {idx:2d}/{len(initials)}] {init:4s}  "
                  f"二进制: {binary}  点形: {dots}  十进制: {decimal}")

            _send_text_uart(init)
            _send_single_braille(decimal, cell=0)
            time.sleep(delay)

        # 再显示韵母（第二个方）
        print("\n--- 韵母部分 ---")
        for idx, final in enumerate(finals, 1):
            binary = pinyin_to_binary[final]
            decimal = int(binary, 2)
            dots = _binary_to_dots(binary)

            print(f"[韵母 {idx:2d}/{len(finals)}] {final:5s}  "
                  f"二进制: {binary}  点形: {dots}  十进制: {decimal}")

            _send_text_uart(final)
            _send_single_braille(decimal, cell=1)
            time.sleep(delay)

        print("\n完整学习完毕！")
        _clear_display()
    except KeyboardInterrupt:
        print("\n\n用户中断，正在退出...")
        _clear_display()
    finally:
        _close_uart()


def lookup_braille(name):
    """
    查询单个声母或韵母的盲文编码并通过串口发送

    参数:
        name: str, 声母或韵母名称，如 "b", "zh", "a", "ang"
    """
    name = name.lower().strip()
    if name not in pinyin_to_binary:
        print(f"未找到 '{name}' 在盲文对照表中")
        print("可用的声母:", ", ".join(initials))
        print("可用的韵母:", ", ".join(finals))
        return

    binary = pinyin_to_binary[name]
    decimal = int(binary, 2)
    dots = _binary_to_dots(binary)

    # 判断是声母还是韵母
    category = "声母" if name in initials else "韵母"

    print(f"查询结果: {name} ({category})")
    print(f"  二进制: {binary}")
    print(f"  点形:   {dots}")
    print(f"  十进制: {decimal}")
    print(f"  十六进制: 0x{decimal:02X}")

    _open_uart()
    try:
        # 发送拼音文本 + 盲文字节
        _send_text_uart(name)
        _send_single_braille(decimal)
        print("已通过串口发送，按 Ctrl+C 关闭...")
        # 保持显示直到用户中断
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        _clear_display()
        print("\n已清除显示")
    finally:
        _close_uart()


def show_table():
    """打印完整的盲文对照表"""
    print("=" * 60)
    print("盲文对照表（拼音 -> 二进制 -> 点形）")
    print("=" * 60)

    print("\n【声母】")
    print("-" * 50)
    for init in initials:
        binary = pinyin_to_binary[init]
        dots = _binary_to_dots(binary)
        decimal = int(binary, 2)
        print(f"  {init:4s} -> {binary}  {dots}  (0x{decimal:02X})")

    print("\n【韵母】")
    print("-" * 50)
    for final in finals:
        binary = pinyin_to_binary[final]
        dots = _binary_to_dots(binary)
        decimal = int(binary, 2)
        print(f"  {final:5s} -> {binary}  {dots}  (0x{decimal:02X})")

    print("\n" + "=" * 60)
    print(f"共 {len(initials)} 个声母, {len(finals)} 个韵母")
    print("=" * 60)


# ===================== 主菜单 =====================

def main():
    while True:
        print("\n" + "=" * 40)
        print("    盲文学习系统（串口UART输出）")
        print("=" * 40)
        print("  1. 学习声母（逐个显示）")
        print("  2. 学习韵母（逐个显示）")
        print("  3. 完整学习（声母 + 韵母）")
        print("  4. 查询单个盲文字符")
        print("  5. 查看完整对照表（不操作硬件）")
        print("  0. 退出")
        print("-" * 40)

        choice = input("请选择功能 [0-5]: ").strip()

        if choice == "1":
            try:
                d = input("每个声母停留时间（秒，默认2）: ").strip()
                delay = float(d) if d else 2.0
            except ValueError:
                delay = 2.0
            learn_initials(delay)

        elif choice == "2":
            learn_finals(8.0)

        elif choice == "3":
            learn_all(8.0)

        elif choice == "4":
            name = input("请输入要查询的声母或韵母（如 b, zh, a, ang）: ").strip()
            lookup_braille(name)

        elif choice == "5":
            show_table()

        elif choice == "0":
            print("退出学习系统，再见！")
            break

        else:
            print("无效选择，请重新输入")


if __name__ == "__main__":
    main()

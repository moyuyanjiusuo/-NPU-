
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
主程序入口：整合所有硬件模块
- 物理按键监听（camera, stop, change）
- 云台控制（gimbal）
- 盲文点显（braille_595）
- 摄像头拍照OCR（camera_ocr）
- 图形界面（jiemian）
- 语音播报（tts_speak）
"""

import threading
import time
import sys
camera_step = 0
# ---------- 导入所有模块 ----------
import gimbal
import jiemian
import braille_595
import buttons
import camera_ocr
import tts_speak   # 新增语音播报模块

# ---------- 配置摄像头索引 ----------
# 根据实际情况修改索引（常用 0 或 1）
CAMERA_INDEX = 0
camera_ocr.DEFAULT_CAMERA_INDEX = CAMERA_INDEX
print(f"设置摄像头索引为 {CAMERA_INDEX}")

# ---------- 按键回调函数 ----------
# 替换 on_camera_button 函数
def on_camera_button():
    """按下 camera 按键：循环执行初始化→位置1~4→初始化..."""
    global camera_step
    print("camera 按键触发 - 执行序列动作")
    try:
        actions = [
            ("已初始化", lambda: gimbal.do_homing()),
            ("已移动到位置1", lambda: gimbal.move_to_position(0)),
            ("已移动到位置2", lambda: gimbal.move_to_position(1)),
            ("已移动到位置3", lambda: gimbal.move_to_position(2)),
            ("已移动到位置4", lambda: gimbal.move_to_position(3)),
            ("已初始化", lambda: gimbal.do_homing()),
        ]
        idx = camera_step % len(actions)
        prompt, action = actions[idx]

        # 1. 先执行云台动作
        action()

        # 2. 如果是位置1~4，执行拍照识别
        if 1 <= idx <= 4:
            success, texts, img_path, txt_path = camera_ocr.capture_once()
            if success and texts:
                if jiemian.main_app is not None:
                    jiemian.main_app.root.after(0,
                                                lambda: jiemian.main_app.show_text('\n'.join(texts)))

        # 3. 最后播报语音（已移动/初始化完成）
        tts_speak.speak_text(prompt, play=True)

        camera_step += 1
    except Exception as e:
        print(f"相机按键执行出错: {e}")

def on_stop_button():
    print("stop 按键触发 - 切换播放/暂停")
    if jiemian.main_app is not None:
        jiemian.main_app.root.after(0, jiemian.main_app.toggle_playback)

def on_change_button():
    print("change 按键触发 - 阅读")
    if jiemian.main_app is not None:
        jiemian.main_app.root.after(0, jiemian.main_app.do_braille)

# ---------- 物理按键监听线程 ----------
def button_listener():
    """循环检测三个按键状态，触发回调"""
    try:
        buttons.init_buttons()
        print("物理按键监听已启动")

        # ---- 新增：等待电平稳定并读取初始状态 ----
        time.sleep(0.5)
        last_camera = buttons.is_camera_button_pressed()
        last_stop = buttons.is_stop_button_pressed()
        last_change = buttons.is_change_button_pressed()
        print(f"初始按键状态: camera={last_camera}, stop={last_stop}, change={last_change}")

        while True:
            pressed = buttons.is_camera_button_pressed()
            if pressed and not last_camera:
                threading.Thread(target=on_camera_button, daemon=True).start()
            last_camera = pressed

            pressed = buttons.is_stop_button_pressed()
            if pressed and not last_stop:
                threading.Thread(target=on_stop_button, daemon=True).start()
            last_stop = pressed

            pressed = buttons.is_change_button_pressed()
            if pressed and not last_change:
                threading.Thread(target=on_change_button, daemon=True).start()
            last_change = pressed

            time.sleep(0.01)
    except Exception as e:
        print(f"按键监听异常: {e}")
    finally:
        buttons.cleanup_buttons()

# ---------- 主入口 ----------
if __name__ == "__main__":
    # 可选：云台硬件初始化（若无硬件可注释）
    # gimbal.init_hardware()
    # gimbal.load_positions()

    # 先测试摄像头是否可用
    try:
        cap = camera_ocr.get_camera()
        print("摄像头初始化成功，准备启动 GUI")
    except Exception as e:
        print(f"警告：摄像头初始化失败（{e}），GUI 可能无视频画面")

    # 启动物理按键监听线程
    t = threading.Thread(target=button_listener, daemon=True)
    t.start()

    # 启动 jiemian 图形界面（阻塞主线程）
    jiemian.run_gui()

    # 退出清理
    buttons.cleanup_buttons()
    camera_ocr.release_camera()
    # gimbal.cleanup_hardware()

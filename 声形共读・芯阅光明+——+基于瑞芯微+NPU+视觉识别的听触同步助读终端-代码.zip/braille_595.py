#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
盲文点显器驱动模块（基于74HC595级联，支持8个盲文方，即4个拼音）
对外接口：display_braille(pinyin_list)
"""

import time
import gpiod
from gpiod.line import Direction, Value

# ---------- 1. 拼音 -> 二进制对照表 ----------
_pinyin_to_binary = {
    "ong": "110010", "weng": "110010",
    "yuan": "101111", "üan": "101111",
    "yun": "111000", "ün": "111000",
    "yong": "111001", "iang": "111001",
    "b": "000011",
    "p": "001111",
    "m": "001101",
    "f": "001011",
    "d": "011001",
    "t": "011110",
    "n": "011101",
    "l": "000111",
    "g": "011011", "j": "011011",
    "k": "000101", "q": "000101",
    "h": "010011", "x": "010011",
    "zhi": "001100", "zh": "001100",
    "chi": "011111", "ch": "011111",
    "shi": "110001", "sh": "110001",
    "r": "010110", "ri": "010110",
    "z": "110101", "zi": "110101",
    "c": "001001", "ci": "001001",
    "s": "001110", "si": "001110",
    "a": "010100",
    "o": "100010", "e": "100010",
    "yi": "001010", "i": "001010",
    "wu": "100101", "u": "100101",
    "yu": "101100", "ü": "101100",
    "er": "010111",
    "ai": "101010",
    "ao": "010110",
    "ei": "101110",
    "ou": "110111",
    "ya": "101011", "ia": "101011",
    "yao": "011100", "iao": "011100",
    "ye": "010001", "ie": "010001",
    "you": "110011", "iou": "110011",
    "wa": "111111", "ua": "111111",
    "wai": "111101", "uai": "111101",
    "wei": "111010", "uei": "111010",
    "wo": "010101", "uo": "010101",
    "yue": "111110", "üe": "111110",
    "an": "100111",
    "en": "110100",
    "ang": "100110",
    "eng": "111100",
    "yan": "101001", "ian": "101001",
    "yang": "101101", "iang_y": "101101",
    "yin": "100011", "in": "100011",
    "ying": "100001", "ing": "100001",
    "uan": "111011", "wan": "111011",
    "uang": "110110", "wang": "110110",
    "uen": "010010", "wen": "010010",
    "ui": "010111", "iu": "110011",
}

_initials = ["zh", "ch", "sh", "b", "p", "m", "f", "d", "t", "n", "l",
             "g", "k", "h", "j", "q", "x", "z", "c", "s", "r"]

def _pinyin_to_decimals(pinyin):
    """将单个拼音转换为两个盲文方（十进制值）"""
    pinyin = pinyin.lower()
    if pinyin in _pinyin_to_binary:
        decimal_value = int(_pinyin_to_binary[pinyin], 2)
        return [0, decimal_value]
    for i in range(min(2, len(pinyin)), 0, -1):
        init = pinyin[:i]
        if init in _initials:
            final = pinyin[i:]
            if final in _pinyin_to_binary:
                init_decimal = int(_pinyin_to_binary[init], 2)
                final_decimal = int(_pinyin_to_binary[final], 2)
                return [init_decimal, final_decimal]
    raise ValueError(f"未识别的拼音: {pinyin}")

# ---------- 2. GPIO 配置 ----------
_CHIP_PATH = "/dev/gpiochip3"
_PIN_OFFSETS = {
    109: 13,   # DS
    108: 12,   # STCP
    98:  2,    # SHCP
}
_DS_PIN = 109
_STCP_PIN = 108
_SHCP_PIN = 98

# 全局请求对象（模块内部使用）
_gpio_req = None

def _setup_gpio():
    """请求三个引脚并设为输出低电平"""
    global _gpio_req
    config = {}
    for abs_pin, offset in _PIN_OFFSETS.items():
        config[offset] = gpiod.LineSettings(
            direction=Direction.OUTPUT,
            output_value=Value.INACTIVE
        )
    try:
        _gpio_req = gpiod.request_lines(
            _CHIP_PATH,
            consumer="braille_595",
            config=config
        )
        print("盲文 GPIO 初始化完成")
    except Exception as e:
        raise RuntimeError(f"GPIO 请求失败: {e}")

def _cleanup_gpio():
    global _gpio_req
    if _gpio_req:
        _gpio_req.release()
        _gpio_req = None
        print("盲文 GPIO 已释放")

def _gpio_write(pin, value):
    if _gpio_req is None:
        raise RuntimeError("GPIO 未初始化")
    offset = _PIN_OFFSETS.get(pin)
    if offset is None:
        raise ValueError(f"未知引脚编号: {pin}")
    _gpio_req.set_value(offset, Value.ACTIVE if value else Value.INACTIVE)

def _send_bytes(bytes_list):
    """发送多个字节到级联的74HC595（低电平有效）"""
    _gpio_write(_STCP_PIN, 0)
    for byte in reversed(bytes_list):
        for i in range(7, -1, -1):
            bit = 1 - ((byte >> i) & 1)   # 低电平有效，取反
            _gpio_write(_DS_PIN, bit)
            _gpio_write(_SHCP_PIN, 1)
            time.sleep(0.000001)
            _gpio_write(_SHCP_PIN, 0)
    _gpio_write(_STCP_PIN, 1)
    time.sleep(0.000001)
    _gpio_write(_STCP_PIN, 0)

# ---------- 3. 对外接口 ----------
def display_braille(pinyin_list):
    """
    显示最多四个拼音的盲文（即8个盲文方）

    参数：
        pinyin_list : list of str，拼音列表，如 ["ni", "hao", "shi", "jie"]
                      最多处理前四个，不足四个时自动补空白方。

    返回：
        bool : True 表示发送成功，False 表示失败（如转换错误或GPIO异常）
    """
    if not pinyin_list:
        print("警告：拼音列表为空")
        return False

    # 取前四个，不足补空
    parts = pinyin_list[:4]
    while len(parts) < 4:
        parts.append("")

    all_bytes = []
    for p in parts:
        if p == "":
            all_bytes.extend([0, 0])
        else:
            try:
                dec1, dec2 = _pinyin_to_decimals(p)
                all_bytes.append(dec1)
                all_bytes.append(dec2)
                print(f"拼音 '{p}' 转换: 方1=0x{dec1:02X}, 方2=0x{dec2:02X}")
            except ValueError as e:
                print(f"拼音 '{p}' 转换错误: {e}，显示为空白")
                all_bytes.extend([0, 0])

    # 确保正好8个字节
    if len(all_bytes) < 8:
        all_bytes.extend([0] * (8 - len(all_bytes)))
    elif len(all_bytes) > 8:
        all_bytes = all_bytes[:8]

    hex_str = ' '.join(f"0x{b:02X}" for b in all_bytes)
    print(f"完整8方数据: {hex_str}")

    try:
        _setup_gpio()
        _send_bytes(all_bytes)
        print("盲文数据已发送")
        return True
    except Exception as e:
        print(f"发送失败: {e}")
        return False
    finally:
        _cleanup_gpio()


# ---------- 测试入口 ----------
if __name__ == "__main__":
    # 简单测试：显示四个拼音
    print("测试显示: ni hao shi jie")
    display_braille(["ni", "hao", "shi", "jie"])

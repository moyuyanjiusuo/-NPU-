#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Y轴 云台控制模块（支持停止回调）

import time
import sys
import gpiod
from gpiod.line import Direction, Value

PIN_MAP = {
    'EN': 8,
    'DIR': 19,
    'PUL': 27,
}
CHIP_PATH = "/dev/gpiochip3"

def _setup_gpio():
    config = {}
    for pin in ['EN', 'DIR', 'PUL']:
        offset = PIN_MAP[pin]
        config[offset] = gpiod.LineSettings(
            direction=Direction.OUTPUT,
            output_value=Value.INACTIVE
        )
    try:
        request = gpiod.request_lines(CHIP_PATH, consumer="y_axis", config=config)
        print("Y轴 GPIO 初始化成功")
        return request
    except Exception as e:
        print(f"Y轴 GPIO 初始化失败: {e}")
        sys.exit(1)

def _cleanup_gpio(request):
    if request:
        request.release()
        print("Y轴 GPIO 已释放")

def _gpio_write(request, pin_name, value):
    offset = PIN_MAP[pin_name]
    request.set_value(offset, Value.ACTIVE if value else Value.INACTIVE)

def _enable_motor(request, enable=True):
    _gpio_write(request, 'EN', 0 if enable else 1)

def _set_direction(request, direction=1):
    _gpio_write(request, 'DIR', direction)

def _pulse_loop(request, duration_high, duration_low, run_time, stop_check=None):
    print(f"Y轴开始产生脉冲（高 {duration_high}s，低 {duration_low}s）")
    if run_time is not None:
        print(f"Y轴将在 {run_time} 秒后自动停止")
    else:
        print("Y轴按 Ctrl+C 停止")

    start = time.time()
    try:
        while True:
            if run_time is not None and (time.time() - start) >= run_time:
                print(f"Y轴运行时间 {run_time} 秒结束")
                break
            if stop_check is not None and stop_check():
                print("Y轴停止条件触发，中断脉冲")
                break

            _gpio_write(request, 'PUL', 1)
            time.sleep(duration_high)

            if run_time is not None and (time.time() - start) >= run_time:
                break
            if stop_check is not None and stop_check():
                print("Y轴停止条件触发，中断脉冲")
                break

            _gpio_write(request, 'PUL', 0)
            time.sleep(duration_low)
    except KeyboardInterrupt:
        print("\nY轴脉冲停止（用户中断）")

def move_y_axis(direction, duration_high=0.0001, duration_low=0.0001,
                run_time=None, stop_check=None):
    if duration_high <= 0 or duration_low <= 0:
        raise ValueError("高低电平时间必须为正数")
    if run_time is not None and run_time <= 0:
        raise ValueError("运行时间必须为正数")

    request = _setup_gpio()
    try:
        _enable_motor(request, True)
        _set_direction(request, 1 if direction else 0)
        if run_time is not None:
            run_time = run_time * 1.5625
        _pulse_loop(request, duration_high, duration_low, run_time, stop_check)
    finally:
        _enable_motor(request, False)
        _cleanup_gpio(request)

if __name__ == "__main__":
    move_y_axis(direction=1, run_time=10.0)
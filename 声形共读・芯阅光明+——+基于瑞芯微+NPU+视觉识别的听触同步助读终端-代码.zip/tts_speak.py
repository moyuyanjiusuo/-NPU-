#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
语音播报模块（基于 Edge TTS）
支持文字转语音、保存为 MP3 文件并播放
"""
#封装版
import os
import asyncio
import subprocess
from datetime import datetime
from pathlib import Path

# 默认语音参数
DEFAULT_VOICE = "zh-CN-XiaoxiaoNeural"
DEFAULT_RATE = "+30%"
DEFAULT_SAVE_DIR = os.path.expanduser("~/Pictures/ocr_captures")

# 全局控制是否启用语音（可由调用者设置）
SPEAK_ENABLED = True


def speak_text(text, save_dir=None, voice=None, rate=None, play=True):
    """
    语音播报文字（同步阻塞，但内部使用 asyncio 处理）

    参数：
        text      : str，要朗读的文字（中文或英文）
        save_dir  : str，MP3 文件保存目录，默认为 ~/Pictures/ocr_captures
        voice     : str，Edge TTS 语音名称，默认为 zh-CN-XiaoxiaoNeural
        rate      : str，语速调整，如 "+30%" 或 "-10%"，默认为 "+30%"
        play      : bool，是否立即播放（播放后文件保留），默认为 True

    返回：
        bool : True 表示成功，False 表示失败（例如未安装 edge-tts）
    """
    if not SPEAK_ENABLED:
        print("[语音] 语音播报已禁用（SPEAK_ENABLED=False）")
        return False

    if not text or not text.strip():
        print("[语音] 文本为空，跳过播报")
        return False

    # 设置默认参数
    if save_dir is None:
        save_dir = DEFAULT_SAVE_DIR
    if voice is None:
        voice = DEFAULT_VOICE
    if rate is None:
        rate = DEFAULT_RATE

    # 确保目录存在
    os.makedirs(save_dir, exist_ok=True)

    # 生成唯一文件名（精确到微秒）
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    mp3_filename = f"speech_{timestamp}.mp3"
    mp3_path = os.path.join(save_dir, mp3_filename)

    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_async_speak(text, mp3_path, voice, rate, play))
        loop.close()
        return True
    except ImportError:
        print("[语音] 未安装 edge-tts，请运行: pip install edge-tts")
        return False
    except Exception as e:
        print(f"[语音] 播报出错: {e}")
        return False


async def _async_speak(text, output_path, voice, rate, play):
    """
    异步执行 Edge TTS：生成 MP3 并可选播放
    """
    try:
        import edge_tts
        communicate = edge_tts.Communicate(text, voice, rate=rate)
        await communicate.save(output_path)
        print(f"[语音] MP3 已保存: {output_path}")

        if play:
            # 使用 mpg123 播放（ALSA 输出）
            subprocess.run(['mpg123', '-o', 'alsa', output_path], check=True)
    except subprocess.CalledProcessError as e:
        print(f"[语音] 播放失败: {e}")
    except Exception as e:
        print(f"[语音] 音频处理错误: {e}")


# ========== 可选：文本转拼音（若需要可保留） ==========
def text_to_pinyin(text):
    """将中文文本转换为拼音（不带声调），需安装 pypinyin"""
    try:
        from pypinyin import pinyin, Style
        pinyin_list = pinyin(text, style=Style.NORMAL, errors='default')
        return ' '.join([item[0] for item in pinyin_list])
    except ImportError:
        print("[语音] 未安装 pypinyin，无法转换拼音")
        return text


# ========== 命令行测试入口 ==========
if __name__ == "__main__":
    # 简单测试
    print("语音播报模块测试")
    test_text = "你好，世界！这是一个测试。"
    speak_text(test_text, play=True)
    print("测试完成")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
摄像头拍照 OCR 封装模块
提供：
1. capture_once() : 单次拍照识别，返回文本列表
2. run_interactive() : 启动交互式窗口（独立 OpenCV 窗口）
3. get_camera() : 获取全局摄像头对象（供外部持续预览）
4. capture_frame() : 从全局摄像头获取一帧
5. release_camera() : 释放摄像头资源
"""

import cv2
import numpy as np
from paddleocr import PaddleOCR
from datetime import datetime
import os
import time

# ---------- 全局配置 ----------
DEFAULT_SAVE_DIR = os.path.expanduser("~/Pictures/ocr_captures")
DEFAULT_CAMERA_INDEX = 21      # 请改为您实际的摄像头索引（如 0）

# ---------- OCR 和摄像头（全局单例） ----------
_ocr = None
_cap = None

def _get_ocr():
    global _ocr
    if _ocr is None:
        try:
            _ocr = PaddleOCR(use_textline_orientation=True, lang='ch')
            print("OCR 初始化成功")
        except Exception as e:
            raise RuntimeError(f"OCR 初始化失败: {e}")
    return _ocr

def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)

# ---------- 公开的摄像头管理函数 ----------
def get_camera(index=DEFAULT_CAMERA_INDEX):
    """获取全局摄像头对象（首次调用时打开），返回 cv2.VideoCapture 对象"""
    global _cap
    if _cap is None:
        _cap = cv2.VideoCapture(index, cv2.CAP_V4L2)
        if not _cap.isOpened():
            _cap = None
            raise IOError(f"无法打开摄像头 /dev/video{index}")
        _cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        _cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        _cap.set(cv2.CAP_PROP_FPS, 30)
        # 预热
        for _ in range(10):
            _cap.read()
    return _cap

def capture_frame(index=DEFAULT_CAMERA_INDEX):
    """
    从全局摄像头捕获一帧
    返回: (ret, frame)  ret 为 bool，frame 为图像数据
    """
    try:
        cap = get_camera(index)
    except IOError as e:
        print(f"摄像头打开失败: {e}")
        return False, None
    ret, frame = cap.read()
    if not ret:
        return False, None
    return True, frame

def release_camera():
    """释放全局摄像头资源"""
    global _cap
    if _cap:
        _cap.release()
        _cap = None
        print("摄像头已释放")

# ---------- OCR 识别函数 ----------
def _ocr_frame(frame):
    ocr = _get_ocr()
    try:
        result = ocr.ocr(frame)
    except Exception as e:
        print(f"OCR 识别出错: {e}")
        return False, [], None
    if result and len(result) > 0 and result[0]:
        texts = []
        for line in result[0]:
            if line and len(line) >= 2:
                # 兼容多种格式
                if isinstance(line[1], (list, tuple)) and len(line[1]) >= 2:
                    text = line[1][0]
                elif isinstance(line[1], str):
                    text = line[1]
                else:
                    # 尝试转为字符串（容错）
                    text = str(line[1])
                texts.append(text)
        print(f"OCR 提取到 {len(texts)} 条文本: {texts}")   # 调试输出
        return True, texts, result
    print("OCR 结果为空或格式异常")   # 调试输出
    return False, [], None

def _save_image(frame, save_dir, prefix="captured"):
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{prefix}_{timestamp}.jpg"
    path = os.path.join(save_dir, filename)
    cv2.imwrite(path, frame)
    return path

def _save_text(texts, save_dir, prefix="recognized"):
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{prefix}_{timestamp}.txt"
    path = os.path.join(save_dir, filename)
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(texts))
    return path

# ---------- 对外主函数 ----------
def capture_once(camera_index=DEFAULT_CAMERA_INDEX, save_dir=DEFAULT_SAVE_DIR,
                 save_image=True, save_text=True):
    """
    执行一次拍照并 OCR 识别（使用全局摄像头）
    返回: (success, texts, image_path, text_path)
    """
    _ensure_dir(save_dir)

    # 捕获一帧（使用全局摄像头）
    ok, frame = capture_frame(camera_index)

    if not ok:
        print("摄像头打开失败")
        return False, [], None, None

    img_path = None
    if save_image:
        img_path = _save_image(frame, save_dir, "captured")
        print(f"照片已保存: {img_path}")

    ok, texts, _ = _ocr_frame(frame)
    if not ok or not texts:
        print("未识别到文字")
        return False, [], img_path, None

    txt_path = None
    if save_text:
        txt_path = _save_text(texts, save_dir, "recognized")
        print(f"识别结果已保存: {txt_path}")

    print(f"识别到 {len(texts)} 条文字: {texts}")
    return True, texts, img_path, txt_path

# ---------- 独立交互窗口（OpenCV） ----------
def run_interactive(camera_index=DEFAULT_CAMERA_INDEX, save_dir=DEFAULT_SAVE_DIR):
    """独立 OpenCV 窗口，按空格拍照，ESC 退出（与主界面无关）"""
    _ensure_dir(save_dir)

    cap = cv2.VideoCapture(camera_index, cv2.CAP_V4L2)
    if not cap.isOpened():
        print(f"错误：无法打开摄像头 /dev/video{camera_index}")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)
    for _ in range(5):
        cap.read()

    cv2.namedWindow('Camera OCR', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Camera OCR', 800, 600)
    print("\n" + "=" * 50)
    print("交互式拍照识别已启动（独立窗口）")
    print("  [空格] 或 [Q] - 拍照并识别")
    print("  [ESC]       - 退出")
    print("  [S]         - 保存当前画面（不识别）")
    print("=" * 50)

    show_result = False
    result_start_time = 0
    result_frame = None
    ocr = _get_ocr()

    while True:
        ret, frame = cap.read()
        if not ret:
            print("获取画面失败")
            break

        if show_result and (time.time() - result_start_time) > 3:
            show_result = False
            result_frame = None

        if show_result and result_frame is not None:
            cv2.imshow('Camera OCR', result_frame)
        else:
            cv2.imshow('Camera OCR', frame)

        key = cv2.waitKey(1) & 0xFF

        if (key == 32 or key == 13 or key == ord('q') or key == ord('Q')) and not show_result:
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] 拍照中...")
            img_path = _save_image(frame, save_dir, "captured")
            print(f"照片已保存: {img_path}")

            print("识别中...")
            try:
                result = ocr.ocr(frame)
            except Exception as e:
                print(f"OCR 错误: {e}")
                result = None

            if result and len(result) > 0 and result[0]:
                texts = []
                result_frame = frame.copy()
                for line in result[0]:
                    if len(line) >= 2:
                        if isinstance(line[1], (list, tuple)) and len(line[1]) >= 2:
                            text = line[1][0]
                        else:
                            text = line[1] if isinstance(line[1], str) else str(line[1])
                        texts.append(text)
                        print(f"  {text}")
                        box = np.array(line[0], dtype=np.int32)
                        cv2.polylines(result_frame, [box], True, (0, 255, 0), 2)
                        cv2.putText(result_frame, text, (box[0][0], box[0][1] - 5),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

                if texts:
                    full_text = '\n'.join(texts)
                    txt_path = _save_text(texts, save_dir, "recognized")
                    print(f"识别结果已保存: {txt_path}")
                    show_result = True
                    result_start_time = time.time()
                    cv2.imshow('Camera OCR', result_frame)
                    print("显示识别结果3秒后自动恢复...")
                else:
                    print("未识别到文字")
            else:
                print("未识别到文字")

        elif key == 27:  # ESC
            break
        elif key == ord('s') or key == ord('S'):
            img_path = _save_image(frame, save_dir, "frame")
            print(f"画面已保存: {img_path}")

    cap.release()
    cv2.destroyAllWindows()
    print("摄像头已释放，退出")

# ---------- 测试入口 ----------
if __name__ == "__main__":
    # 简单测试：单次识别
    print("测试单次拍照识别...")
    success, texts, img_path, txt_path = capture_once()
    if success:
        print("识别成功，文字：", texts)
    # 如需交互模式，取消注释下面一行
    # run_interactive()
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#封装
"""
按键检测模块（三按键合一）
- change 按键：GPIO 101（偏移 5）
- stop  按键：GPIO 105（偏移 9）
- camera 按键：GPIO 103（偏移 7）

所有按键均为低电平有效（按下为 0），内部有上拉电阻。
每个检测函数返回布尔值，表示该按键是否刚刚被按下（下降沿检测，带去抖动）。
"""

import time
import gpiod
from gpiod.line import Direction, Value, Bias

# ==================== GPIO 配置 ====================
CHIP_PATH = "/dev/gpiochip3"
# 偏移量计算：GPIO编号 - 96
CHANGE_OFFSET = 5    # GPIO 101
STOP_OFFSET = 9      # GPIO 105
CAMERA_OFFSET = 7    # GPIO 103

# 全局请求对象（同时请求三个引脚）
_gpio_request = None

# 各按键的状态变量（上次电平、上次触发时间 ms）
_change_last_state = 1      # 默认高电平（未按下）
_change_last_time = 0
_stop_last_state = 1
_stop_last_time = 0
_camera_last_state = 1
_camera_last_time = 0


def init_buttons():
    """初始化所有按键 GPIO（请求三个引脚）"""
    global _gpio_request
    config = {
        CHANGE_OFFSET: gpiod.LineSettings(
            direction=Direction.INPUT,
            bias=Bias.PULL_UP
        ),
        STOP_OFFSET: gpiod.LineSettings(
            direction=Direction.INPUT,
            bias=Bias.PULL_UP
        ),
        CAMERA_OFFSET: gpiod.LineSettings(
            direction=Direction.INPUT,
            bias=Bias.PULL_UP
        ),
    }
    try:
        _gpio_request = gpiod.request_lines(
            CHIP_PATH,
            consumer="button_handlers",
            config=config
        )
        print("按键 GPIO 初始化成功")
    except Exception as e:
        raise RuntimeError(f"按键 GPIO 初始化失败: {e}")


def cleanup_buttons():
    """释放所有 GPIO"""
    global _gpio_request
    if _gpio_request:
        _gpio_request.release()
        _gpio_request = None
        print("按键 GPIO 已释放")


def _read_pin(offset):
    """读取指定偏移引脚电平（返回 1 或 0）"""
    if _gpio_request is None:
        raise RuntimeError("GPIO 未初始化")
    val = _gpio_request.get_value(offset)
    return 1 if val == Value.ACTIVE else 0


def _is_pressed(offset, last_state_ref, last_time_ref, debounce_ms=50):
    """
    内部函数：检测指定引脚是否有下降沿（按键按下）
    使用全局变量进行状态跟踪（通过引用更新）
    由于 Python 无法直接修改整数全局变量的引用，我们使用字典或列表，
    但为了清晰，这里分别实现三个独立函数，而非使用此通用函数。
    """
    # 此函数仅作为设计说明，实际不使用
    pass


# ==================== 三个独立的按键检测函数 ====================

def is_change_button_pressed():
    """
    检测 change 按键是否被按下（GPIO 101）
    返回 True 表示刚按下（下降沿），False 表示未按下或已释放
    """
    global _change_last_state, _change_last_time
    current = _read_pin(CHANGE_OFFSET)
    now = time.time() * 1000  # 毫秒
    pressed = False

    # 检测下降沿（1 -> 0）
    if _change_last_state == 1 and current == 0:
        if (now - _change_last_time) > 50:  # 去抖动
            time.sleep(0.02)  # 再次确认
            if _read_pin(CHANGE_OFFSET) == 0:
                pressed = True
                _change_last_time = now

    _change_last_state = current
    return pressed


def is_stop_button_pressed():
    """
    检测 stop 按键是否被按下（GPIO 105）
    返回 True 表示刚按下（下降沿），False 表示未按下或已释放
    """
    global _stop_last_state, _stop_last_time
    current = _read_pin(STOP_OFFSET)
    now = time.time() * 1000
    pressed = False

    if _stop_last_state == 1 and current == 0:
        if (now - _stop_last_time) > 50:
            time.sleep(0.02)
            if _read_pin(STOP_OFFSET) == 0:
                pressed = True
                _stop_last_time = now

    _stop_last_state = current
    return pressed


def is_camera_button_pressed():
    """
    检测 camera 按键是否被按下（GPIO 103）
    返回 True 表示刚按下（下降沿），False 表示未按下或已释放
    """
    global _camera_last_state, _camera_last_time
    current = _read_pin(CAMERA_OFFSET)
    now = time.time() * 1000
    pressed = False

    if _camera_last_state == 1 and current == 0:
        if (now - _camera_last_time) > 50:
            time.sleep(0.02)
            if _read_pin(CAMERA_OFFSET) == 0:
                pressed = True
                _camera_last_time = now

    _camera_last_state = current
    return pressed


# ==================== 测试入口 ====================
if __name__ == "__main__":
    try:
        init_buttons()
        print("监控三个按键，按下时输出对应的标识：")
        print("  [Change]  -> 输出 'change'")
        print("  [Stop]    -> 输出 'stop'")
        print("  [Camera]  -> 输出 'camera'")
        print("按 Ctrl+C 退出")

        while True:
            if is_change_button_pressed():
                print("change")
            if is_stop_button_pressed():
                print("stop")
            if is_camera_button_pressed():
                print("camera")
            time.sleep(0.01)  # 避免占用过高CPU

    except KeyboardInterrupt:
        print("\n程序退出")
    finally:
        cleanup_buttons()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
云台控制模块（纯硬件控制，无 GUI）
"""

import time
import gpiod
from gpiod.line import Direction, Value, Bias
import json
import os
import threading

# 导入底层驱动
import x_axis
import y_axis

# ==================== 硬件引脚配置 ====================
PIN_MAP_X = {'EN': 14, 'DIR': 6, 'PUL': 4}
PIN_MAP_Y = {'EN': 8, 'DIR': 19, 'PUL': 27}
CHIP_PATH = "/dev/gpiochip3"

SENSOR_X_CHIP = "/dev/gpiochip4"
SENSOR_X_OFFSET = 10
SENSOR_Y_CHIP = "/dev/gpiochip3"
SENSOR_Y_OFFSET = 21

# ==================== 云台参数 ====================
PULSE_HIGH = 0.0001
PULSE_LOW  = 0.0001
DEFAULT_POSITIONS = [
    (0, 3, 0, 9),
    (0, 0, 0, 10),
    (0, 13, 1, 10),
    (0, 0, 0, 10),
]
POSITIONS = DEFAULT_POSITIONS.copy()
STABILIZE_TIME = 0.5
POSITIONS_FILE = "positions.json"

# ==================== GPIO 全局变量 ====================
_gpio_req_sensor_x = None
_gpio_req_sensor_y = None
_hardware_initialized = False

_stop_requested = False
_stop_lock = threading.Lock()

# ==================== 位置参数管理 ====================
def load_positions():
    global POSITIONS
    if os.path.exists(POSITIONS_FILE):
        try:
            with open(POSITIONS_FILE, 'r') as f:
                data = json.load(f)
            if isinstance(data, list) and len(data) == 4:
                POSITIONS = [tuple(p) for p in data]
                print("已加载保存的位置参数")
                return
        except Exception as e:
            print(f"加载位置文件失败，使用默认值: {e}")
    POSITIONS = DEFAULT_POSITIONS.copy()
    print("使用默认位置参数")

def save_positions():
    try:
        with open(POSITIONS_FILE, 'w') as f:
            json.dump(POSITIONS, f, indent=2)
        print("位置参数已保存到", POSITIONS_FILE)
    except Exception as e:
        print(f"保存失败: {e}")

# ==================== 硬件初始化 / 清理 ====================
def init_hardware():
    global _gpio_req_sensor_x, _gpio_req_sensor_y, _hardware_initialized
    if _hardware_initialized:
        return
    config_x = {SENSOR_X_OFFSET: gpiod.LineSettings(direction=Direction.INPUT, bias=Bias.PULL_UP)}
    config_y = {SENSOR_Y_OFFSET: gpiod.LineSettings(direction=Direction.INPUT, bias=Bias.PULL_UP)}
    try:
        _gpio_req_sensor_x = gpiod.request_lines(SENSOR_X_CHIP, consumer="sensor_x", config=config_x)
        _gpio_req_sensor_y = gpiod.request_lines(SENSOR_Y_CHIP, consumer="sensor_y", config=config_y)
        print("传感器 GPIO 初始化成功")
    except Exception as e:
        raise RuntimeError(f"传感器 GPIO 初始化失败: {e}")
    _hardware_initialized = True

def cleanup_hardware():
    global _gpio_req_sensor_x, _gpio_req_sensor_y, _hardware_initialized
    if _gpio_req_sensor_x:
        _gpio_req_sensor_x.release()
        _gpio_req_sensor_x = None
    if _gpio_req_sensor_y:
        _gpio_req_sensor_y.release()
        _gpio_req_sensor_y = None
    _hardware_initialized = False
    print("所有 GPIO 已释放")

def _ensure_hardware():
    if not _hardware_initialized:
        init_hardware()

# ==================== 传感器读取 ====================
def sensor_x_triggered():
    if _gpio_req_sensor_x is None:
        return False
    return _gpio_req_sensor_x.get_value(SENSOR_X_OFFSET) == Value.INACTIVE

def sensor_y_triggered():
    if _gpio_req_sensor_y is None:
        return False
    return _gpio_req_sensor_y.get_value(SENSOR_Y_OFFSET) == Value.INACTIVE

# ==================== 停止控制 ====================
def request_stop():
    global _stop_requested
    with _stop_lock:
        _stop_requested = True
    print("停止请求已发送")

def reset_stop():
    global _stop_requested
    with _stop_lock:
        _stop_requested = False
    print("停止标志已重置")

def is_stop_requested():
    with _stop_lock:
        return _stop_requested

# ==================== 移动函数（调用底层驱动）====================
def move_x(direction, run_time, ignore_sensor=False, ignore_initial=False):
    _ensure_hardware()
    if run_time <= 0:
        return
    # 初始传感器检查（除非忽略）
    if not ignore_initial and not ignore_sensor and sensor_x_triggered():
        print("X轴传感器已触发，拒绝移动")
        return

    # 构造停止检查回调
    def stop_check():
        if is_stop_requested():
            return True
        if not ignore_sensor and sensor_x_triggered():
            print("X轴传感器触发，停止移动")
            return True
        return False

    # 调用底层驱动（底层内部已做时间缩放）
    x_axis.move_x_axis(direction, duration_high=PULSE_HIGH, duration_low=PULSE_LOW,
                       run_time=run_time, stop_check=stop_check)
    print("X轴移动结束")

def move_y(direction, run_time, ignore_sensor=False, ignore_initial=False):
    _ensure_hardware()
    if run_time <= 0:
        return
    if not ignore_initial and not ignore_sensor and sensor_y_triggered():
        print("Y轴传感器已触发，拒绝移动")
        return

    def stop_check():
        if is_stop_requested():
            return True
        if not ignore_sensor and sensor_y_triggered():
            print("Y轴传感器触发，停止移动")
            return True
        return False

    y_axis.move_y_axis(direction, duration_high=PULSE_HIGH, duration_low=PULSE_LOW,
                       run_time=run_time, stop_check=stop_check)
    print("Y轴移动结束")

# ==================== 回零 ====================
def do_homing():
    _ensure_hardware()
    reset_stop()
    print("\n>>> 执行初始化回零 <<<")
    print(f"初始 X 传感器: {sensor_x_triggered()}, Y 传感器: {sensor_y_triggered()}")

    print("X轴正向（向右）回零...")
    move_x(1, 20, ignore_sensor=False, ignore_initial=True)
    print("X轴回零完成")

    print("Y轴正向（向上）回零...")
    move_y(1, 20, ignore_sensor=False, ignore_initial=True)
    print("Y轴回零完成")
    print("初始化回零结束\n")

# ==================== 预设位置移动 ====================
def move_to_position(index):
    if index < 0 or index >= len(POSITIONS):
        print(f"位置索引 {index} 无效")
        return
    x_dir, x_time, y_dir, y_time = POSITIONS[index]
    print(f"\n>>> 移动至位置 {index+1} <<<")
    if x_time > 0:
        move_x(x_dir, x_time, ignore_sensor=True)
    if y_time > 0:
        move_y(y_dir, y_time, ignore_sensor=True)
    time.sleep(STABILIZE_TIME)

# ==================== 测试入口 ====================
if __name__ == "__main__":
    print("=== 云台控制模块测试 ===")
    try:
        init_hardware()
        load_positions()
        do_homing()
        move_to_position(0)
    except KeyboardInterrupt:
        print("用户中断")
    finally:
        cleanup_hardware()
        print("测试结束")
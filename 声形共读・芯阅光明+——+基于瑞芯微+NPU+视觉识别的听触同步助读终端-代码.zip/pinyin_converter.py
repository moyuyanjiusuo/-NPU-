#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文字转拼音模块（基于 pypinyin）
提供中文文本转拼音（不带声调）功能
"""
#封装版
from pypinyin import pinyin, Style

def text_to_pinyin(text):
    """
    将中文文本转换为拼音（不带声调），空格分隔

    参数：
        text : str，中文文本

    返回：
        str，拼音字符串，如 "ni hao shi jie"
    """
    if not text or not text.strip():
        return ""
    pinyin_list = pinyin(text, style=Style.NORMAL, errors='default')
    return ' '.join([item[0] for item in pinyin_list])


def text_to_pinyin_list(text):
    """
    将中文文本转换为拼音列表（每个字的拼音）

    参数：
        text : str，中文文本

    返回：
        list，每个字的拼音，如 ["ni", "hao"]
    """
    if not text or not text.strip():
        return []
    pinyin_list = pinyin(text, style=Style.NORMAL, errors='default')
    return [item[0] for item in pinyin_list]


# 简单测试入口
if __name__ == "__main__":
    test_text = "你好，世界！"
    print(f"原文: {test_text}")
    print(f"拼音(字符串): {text_to_pinyin(test_text)}")
    print(f"拼音(列表): {text_to_pinyin_list(test_text)}")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
整合云台控制、OCR、语音、盲文的 Tkinter GUI
- 主界面：实时摄像头预览、识别文字、拍照（打开合并窗口）、播放/暂停、阅读、学习
- 拍照窗口：集成初始化、四个位置移动拍照、参数调整（上下左右+距离）
- 学习窗口：声母、韵母、拼音学习
"""

import tkinter as tk
from tkinter import messagebox, ttk
import cv2
import numpy as np
from PIL import Image, ImageTk
import threading
import time
import os
import sys
import json
import gpiod
from gpiod.line import Direction, Value, Bias
from braille_learn import pinyin_to_binary, initials, finals, _send_single_braille, _setup_gpio, _cleanup_gpio
import camera_ocr
import gimbal   # 新增：导入云台控制模块

# ===== 595 双字节盲文驱动（保持不变）=====
DS_PIN = 109
STCP_PIN = 108
SHCP_PIN = 98

_595_initialized = False

def gpio_export(pin):
    if not os.path.exists(f"/sys/class/gpio/gpio{pin}"):
        with open("/sys/class/gpio/export", 'w') as f:
            f.write(str(pin))

def gpio_direction(pin, direction):
    with open(f"/sys/class/gpio/gpio{pin}/direction", 'w') as f:
        f.write(direction)

def gpio_write(pin, value):
    with open(f"/sys/class/gpio/gpio{pin}/value", 'w') as f:
        f.write('1' if value else '0')

def gpio_unexport(pin):
    try:
        with open("/sys/class/gpio/unexport", 'w') as f:
            f.write(str(pin))
    except:
        pass

def setup_595():
    global _595_initialized
    if _595_initialized:
        return
    for pin in [DS_PIN, SHCP_PIN, STCP_PIN]:
        gpio_export(pin)
        gpio_direction(pin, "out")
        gpio_write(pin, 0)
    _595_initialized = True
    print("595 双字节盲文驱动 GPIO 初始化完成")

def cleanup_595():
    global _595_initialized
    if not _595_initialized:
        return
    for pin in [DS_PIN, SHCP_PIN, STCP_PIN]:
        gpio_unexport(pin)
    _595_initialized = False
    print("595 GPIO 已释放")

def send_dual_595(byte1, byte2):
    """发送两个字节到级联的74HC595（byte1为第一个方，byte2为第二个方）"""
    gpio_write(STCP_PIN, 0)
    for i in range(7, -1, -1):
        bit = 1 - ((byte2 >> i) & 1)
        gpio_write(DS_PIN, bit)
        gpio_write(SHCP_PIN, 1)
        time.sleep(0.000001)
        gpio_write(SHCP_PIN, 0)
    for i in range(7, -1, -1):
        bit = 1 - ((byte1 >> i) & 1)
        gpio_write(DS_PIN, bit)
        gpio_write(SHCP_PIN, 1)
        time.sleep(0.000001)
        gpio_write(SHCP_PIN, 0)
    gpio_write(STCP_PIN, 1)
    time.sleep(0.000001)
    gpio_write(STCP_PIN, 0)

# ===== OCR、语音、盲文 =====
try:
    import paddleocr
    from paddleocr import PaddleOCR
    OCR_AVAILABLE = True
except:
    OCR_AVAILABLE = False
    print("PaddleOCR 未安装，OCR功能不可用")

try:
    import edge_tts
    import asyncio
    import pygame
    TTS_AVAILABLE = True
except:
    TTS_AVAILABLE = False
    print("语音模块未安装，播放功能不可用")

try:
    from braille_595 import display_braille
    BRAILLE_AVAILABLE = True
except:
    BRAILLE_AVAILABLE = False
    def display_braille(*args, **kwargs):
        print("盲文输出模拟:", args)
        return True

try:
    from pinyin_converter import text_to_pinyin_list
    PINYIN_AVAILABLE = True
except:
    PINYIN_AVAILABLE = False
    def text_to_pinyin_list(text):
        return [c for c in text if c.strip()]

ocr = None
camera_cap = None          # 将由 camera-ocr 提供
current_text = ""
pinyin_list = []
is_playing = False
is_paused = False
play_thread = None
state = 'idle'
main_app = None   # 全局变量，供外部访问主窗口实例

def init_camera():
    global camera_cap
    try:
        camera_cap = camera_ocr.get_camera()
        print("摄像头初始化成功（由 camera-ocr 管理）")
    except Exception as e:
        print(f"摄像头初始化失败: {e}")
        camera_cap = None

def init_ocr():
    global ocr
    if OCR_AVAILABLE:
        try:
            ocr = PaddleOCR(use_textline_orientation=True, lang='ch')
            print("OCR 初始化成功")
        except Exception as e:
            print(f"OCR 初始化失败: {e}")
            ocr = None
    else:
        ocr = None

def capture_and_recognize():
    success, texts, img_path, txt_path = camera_ocr.capture_once()
    if success:
        return '\n'.join(texts)
    else:
        return ""

def full_scan():
    print("full_scan 已禁用")
    return ""

def play_voice_with_control(text, callback=None):
    global is_playing, is_paused, state
    if not TTS_AVAILABLE:
        print("语音不可用")
        return
    try:
        async def gen_mp3():
            comm = edge_tts.Communicate(text, "zh-CN-XiaoxiaoNeural", rate="+30%")
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as f:
                tmp = f.name
            await comm.save(tmp)
            return tmp

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        mp3_path = loop.run_until_complete(gen_mp3())
        loop.close()

        pygame.mixer.init()
        pygame.mixer.music.load(mp3_path)
        pygame.mixer.music.play()
        is_playing = True
        is_paused = False
        state = 'playing'

        while is_playing:
            if not pygame.mixer.music.get_busy() and not is_paused:
                break
            if is_paused:
                pygame.mixer.music.pause()
                while is_paused and is_playing:
                    time.sleep(0.1)
                if not is_playing:
                    break
                pygame.mixer.music.unpause()
            time.sleep(0.1)

        pygame.mixer.music.stop()
        pygame.mixer.quit()
        os.unlink(mp3_path)
    except Exception as e:
        print(f"语音播放错误: {e}")
    finally:
        is_playing = False
        is_paused = False
        state = 'idle'
        if callback:
            callback()

def start_voice(text, callback=None):
    global play_thread
    if is_playing:
        return
    play_thread = threading.Thread(target=play_voice_with_control, args=(text, callback), daemon=True)
    play_thread.start()

def toggle_pause():
    global is_paused
    if is_playing:
        is_paused = not is_paused
        return is_paused

def show_braille_page(page_num):
    if not pinyin_list:
        return 0
    total = (len(pinyin_list) + 3) // 4
    if page_num < 0: page_num = 0
    if page_num >= total: page_num = total - 1
    start = page_num * 4
    end = min(start + 4, len(pinyin_list))
    page_pinyins = pinyin_list[start:end]
    success = display_braille(page_pinyins)
    if success:
        return page_num
    return -1

# ===== 主界面 =====
class MainApp:
    def __init__(self, root):
        self.root = root
        root.title("智能阅读系统")
        root.geometry("900x700")
        root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # ---- 视频预览 ----
        self.video_label = tk.Label(root, bg="black")
        self.video_label.pack(pady=10)

        # ---- 文本显示框 ----
        self.text_area = tk.Text(root, height=5, font=("SimHei", 12), wrap=tk.WORD)
        self.text_area.pack(pady=5, fill=tk.X)
        self.text_area.config(state=tk.DISABLED)

        # ---- 按钮 ----
        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        self.btn_capture = tk.Button(btn_frame, text="拍照", width=10, height=2,
                                    command=self.open_capture_window, bg="#4CAF50", fg="white")
        self.btn_capture.pack(side=tk.LEFT, padx=10)

        self.btn_play = tk.Button(btn_frame, text="播放/暂停", width=10, height=2,
                                 command=self.toggle_playback, bg="#2196F3", fg="white")
        self.btn_play.pack(side=tk.LEFT, padx=10)

        self.btn_read = tk.Button(btn_frame, text="阅读", width=10, height=2,
                                 command=self.do_braille, bg="#FF9800", fg="white")
        self.btn_read.pack(side=tk.LEFT, padx=10)

        self.btn_learn = tk.Button(btn_frame, text="学习", width=10, height=2,
                                   command=self.open_learn_window, bg="#9C27B0", fg="white")
        self.btn_learn.pack(side=tk.LEFT, padx=10)

        # ---- 状态栏 ----
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        status_bar = tk.Label(root, textvariable=self.status_var, bd=1, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # ---- 初始化 ----
        init_camera()
        init_ocr()
        gimbal.load_positions()       # 使用 gimbal 加载位置
        try:
            gimbal.init_hardware()    # 使用 gimbal 初始化传感器
            print("云台硬件初始化成功")
        except Exception as e:
            print(f"传感器初始化失败（模拟运行）: {e}")

        self.capture_win = None
        self.learn_win = None
        self.current_text = ""
        self._braille_page = 0
        self.latest_frame = None
        self.update_video()

    # ---------- 视频更新循环 ----------
    def update_video(self):
        if camera_cap is None:
            self.root.after(30, self.update_video)
            return
        ret, frame = camera_ocr.capture_frame()
        if ret:
            self.latest_frame = frame.copy()
            img = cv2.resize(frame, (640, 480))
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_pil = Image.fromarray(img_rgb)
            imgtk = ImageTk.PhotoImage(image=img_pil)
            self.video_label.imgtk = imgtk
            self.video_label.config(image=imgtk)

            if self.capture_win is not None:
                self.capture_win.update_video_from_main(frame)
        self.root.after(30, self.update_video)

    def set_status(self, msg):
        self.status_var.set(msg)

    def show_text(self, text):
        global pinyin_list  # 放在第一行
        if PINYIN_AVAILABLE and text:
            raw_pinyins = text_to_pinyin_list(text)
            pinyins = [p for p in raw_pinyins if p.isalpha()]
            pinyin_list = pinyins
            display_text = ' '.join(pinyins)
        else:
            pinyin_list = [c for c in text if c.strip()]
            display_text = text

        self.text_area.config(state=tk.NORMAL)
        self.text_area.delete(1.0, tk.END)
        self.text_area.insert(tk.END, display_text)
        self.text_area.config(state=tk.DISABLED)

        self.current_text = text
        self._braille_page = 0

    def open_capture_window(self):
        if self.capture_win is not None:
            self.capture_win.lift()
            return
        self.capture_win = CaptureWindow(self.root, self)
        self.capture_win.protocol("WM_DELETE_WINDOW", self.capture_win_closed)

    def capture_win_closed(self):
        if self.capture_win:
            self.capture_win.destroy()
            self.capture_win = None

    def open_learn_window(self):
        if self.learn_win is not None:
            self.learn_win.lift()
            return
        self.learn_win = LearnWindow(self.root, self)
        self.learn_win.protocol("WM_DELETE_WINDOW", self.learn_win_closed)

    def learn_win_closed(self):
        if self.learn_win:
            self.learn_win.destroy()
            self.learn_win = None

    def toggle_playback(self):
        if not self.current_text:
            messagebox.showinfo("提示", "没有可朗读的文字")
            return
        if is_playing:
            paused = toggle_pause()
            self.set_status("暂停" if paused else "继续")
        else:
            start_voice(self.current_text, callback=lambda: self.set_status("播放结束"))
            self.set_status("正在播放...")

    def do_braille(self):
        if not self.current_text:
            messagebox.showinfo("提示", "没有可输出的文字")
            return
        if not pinyin_list:
            messagebox.showinfo("提示", "无法生成拼音")
            return
        if BRAILLE_AVAILABLE:
            total_pages = (len(pinyin_list) + 3) // 4
            if total_pages == 0:
                self.set_status("无拼音可显示")
                return
            # 如果当前页码超出，重置为0（循环）
            if self._braille_page >= total_pages:
                self._braille_page = 0
            page = show_braille_page(self._braille_page)
            if page >= 0:
                self.set_status(f"盲文第 {page + 1}/{total_pages} 页")
                # 页码加1，为下次点击准备
                self._braille_page += 1
                if self._braille_page >= total_pages:
                    self._braille_page = 0  # 循环，可改为不循环则注释掉
            else:
                self.set_status("盲文输出失败")
        else:
            messagebox.showinfo("提示", "盲文硬件未连接")

    def on_closing(self):
        camera_ocr.release_camera()
        gimbal.cleanup_hardware()   # 使用 gimbal 清理传感器
        self.root.destroy()


# ===== 拍照/参数窗口（带视频预览） =====
class CaptureWindow(tk.Toplevel):
    def __init__(self, master, main_app):
        super().__init__(master)
        self.main_app = main_app
        self.title("拍照与参数控制")
        self.geometry("850x750")
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.configure(bg="#f0f0f0")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        main_frame = tk.Frame(self, bg="#f0f0f0")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # ---- 视频预览（缩小） ----
        video_frame = tk.LabelFrame(main_frame, text="摄像头预览", bg="#f0f0f0", font=("Microsoft YaHei", 10))
        video_frame.pack(fill=tk.X, pady=(0,10))
        self.video_label = tk.Label(video_frame, bg="black", relief=tk.SUNKEN, width=320, height=240)
        self.video_label.pack(padx=5, pady=5)
        self.video_label.config(text="等待视频...", fg="white", font=("Microsoft YaHei", 14))

        # ---- 初始化按钮 ----
        init_btn = tk.Button(main_frame, text="初始化回零", command=self.do_init,
                             bg="#FF5722", fg="white", font=("Microsoft YaHei", 10), padx=20, pady=6)
        init_btn.pack(pady=(0,10))

        # ---- 参数表格 ----
        param_frame = tk.LabelFrame(main_frame, text="位置参数设置（方向 + 距离滑块）",
                                    bg="#f0f0f0", font=("Microsoft YaHei", 10))
        param_frame.pack(fill=tk.X, pady=10)

        header = tk.Frame(param_frame, bg="#f0f0f0")
        header.pack(fill=tk.X, pady=2)
        tk.Label(header, text="位置", width=6, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="X方向", width=8, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="X距离", width=18, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="Y方向", width=8, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)
        tk.Label(header, text="Y距离", width=18, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)

        self.param_vars = []
        for i in range(4):
            row = tk.Frame(param_frame, bg="#f0f0f0")
            row.pack(fill=tk.X, pady=3)

            tk.Label(row, text=f"位置{i+1}", width=6, anchor=tk.CENTER, bg="#f0f0f0").pack(side=tk.LEFT, padx=2)

            x_dir_var = tk.StringVar(value="左" if gimbal.POSITIONS[i][0] == 0 else "右")
            x_dir_cb = ttk.Combobox(row, textvariable=x_dir_var, values=["左", "右"], state="readonly", width=6)
            x_dir_cb.pack(side=tk.LEFT, padx=2)

            x_time_var = tk.DoubleVar(value=gimbal.POSITIONS[i][1])
            x_scale = tk.Scale(row, from_=0, to=20, resolution=0.5, orient=tk.HORIZONTAL,
                               variable=x_time_var, length=150, showvalue=False)
            x_scale.pack(side=tk.LEFT, padx=5)
            x_label = tk.Label(row, text=f"{gimbal.POSITIONS[i][1]:.1f}", width=4, bg="#f0f0f0")
            x_label.pack(side=tk.LEFT, padx=2)
            def make_x_callback(lbl, var):
                return lambda v: lbl.config(text=f"{var.get():.1f}")
            x_scale.configure(command=make_x_callback(x_label, x_time_var))

            y_dir_var = tk.StringVar(value="下" if gimbal.POSITIONS[i][2] == 0 else "上")
            y_dir_cb = ttk.Combobox(row, textvariable=y_dir_var, values=["下", "上"], state="readonly", width=6)
            y_dir_cb.pack(side=tk.LEFT, padx=2)

            y_time_var = tk.DoubleVar(value=gimbal.POSITIONS[i][3])
            y_scale = tk.Scale(row, from_=0, to=20, resolution=0.5, orient=tk.HORIZONTAL,
                               variable=y_time_var, length=150, showvalue=False)
            y_scale.pack(side=tk.LEFT, padx=5)
            y_label = tk.Label(row, text=f"{gimbal.POSITIONS[i][3]:.1f}", width=4, bg="#f0f0f0")
            y_label.pack(side=tk.LEFT, padx=2)
            def make_y_callback(lbl, var):
                return lambda v: lbl.config(text=f"{var.get():.1f}")
            y_scale.configure(command=make_y_callback(y_label, y_time_var))

            self.param_vars.append((x_dir_var, x_time_var, y_dir_var, y_time_var, x_scale, y_scale, x_label, y_label))

        # ---- 位置拍照按钮 ----
        btn_frame = tk.Frame(main_frame, bg="#f0f0f0")
        btn_frame.pack(fill=tk.X, pady=10)

        colors = ["#4CAF50", "#2196F3", "#FF9800", "#9C27B0"]
        for i in range(4):
            btn = tk.Button(btn_frame, text=f"位置{i+1}（拍照识别）",
                            command=lambda idx=i: self.do_move_and_capture(idx),
                            bg=colors[i], fg="white", font=("Microsoft YaHei", 10), padx=10, pady=5)
            btn.pack(side=tk.LEFT, padx=8, expand=True, fill=tk.X)

        # ---- 底部按钮 ----
        bottom_btn_frame = tk.Frame(main_frame, bg="#f0f0f0")
        bottom_btn_frame.pack(pady=5)

        save_btn = tk.Button(bottom_btn_frame, text="保存参数", command=self.save_params,
                             bg="#607D8B", fg="white", font=("Microsoft YaHei", 10), padx=20, pady=6)
        save_btn.pack(side=tk.LEFT, padx=10)

        pause_btn = tk.Button(bottom_btn_frame, text="暂停", command=self.pause_action,
                              bg="#FFC107", fg="white", font=("Microsoft YaHei", 10), padx=20, pady=6)
        pause_btn.pack(side=tk.LEFT, padx=10)

        back_btn = tk.Button(bottom_btn_frame, text="返回", command=self.on_close,
                             bg="#795548", fg="white", font=("Microsoft YaHei", 10), padx=20, pady=6)
        back_btn.pack(side=tk.LEFT, padx=10)

        # 状态栏
        self.status_var = tk.StringVar(value="就绪")
        status_bar = tk.Label(self, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W,
                              font=("Microsoft YaHei", 10), bg="#f0f0f0")
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # 启动自身视频刷新
        self.running = True
        self.after(50, self._refresh_video)

    def _refresh_video(self):
        if not self.running:
            return
        frame = self.main_app.latest_frame
        if frame is not None:
            self.update_video_from_main(frame)
        self.after(50, self._refresh_video)

    def update_video_from_main(self, frame):
        if frame is None:
            return
        display = cv2.resize(frame, (320, 240))
        img_rgb = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)
        img_pil = Image.fromarray(img_rgb)
        imgtk = ImageTk.PhotoImage(image=img_pil)
        self.video_label.config(text="")
        self.video_label.imgtk = imgtk
        self.video_label.config(image=imgtk)

    def set_status(self, msg):
        self.status_var.set(msg)

    def do_init(self):
        self.set_status("回零中...")
        threading.Thread(target=self._init_worker, daemon=True).start()

    def _init_worker(self):
        try:
            gimbal.do_homing()   # 使用 gimbal 回零
            self.after(0, lambda: self.set_status("回零完成"))
        except Exception as e:
            err_msg = str(e)
            self.after(0, lambda: self.set_status(f"错误: {err_msg}"))

    def do_move_and_capture(self, idx):
        gimbal.reset_stop()   # 清除之前的停止请求
        self.set_status(f"移动至位置{idx+1}...")
        threading.Thread(target=self._move_capture_worker, args=(idx,), daemon=True).start()

    def _move_capture_worker(self, idx):
        try:
            gimbal.move_to_position(idx)   # 使用 gimbal 移动
            self.after(0, lambda: self.set_status("拍照识别中..."))
            text = capture_and_recognize()
            if text:
                self.after(0, lambda: self.main_app.show_text(text))
                self.after(0, lambda: self.set_status(f"位置{idx+1}识别完成"))
            else:
                self.after(0, lambda: self.set_status("未识别到文字"))
        except Exception as e:
            err_msg = str(e)
            self.after(0, lambda: self.set_status(f"错误: {err_msg}"))

    def save_params(self):
        try:
            new_pos = []
            for (x_dir_var, x_time_var, y_dir_var, y_time_var, _, _, _, _) in self.param_vars:
                x_dir = 0 if x_dir_var.get() == "左" else 1
                x_time = x_time_var.get()
                y_dir = 0 if y_dir_var.get() == "下" else 1
                y_time = y_time_var.get()
                new_pos.append((x_dir, x_time, y_dir, y_time))
            # 更新 gimbal 的 POSITIONS 并保存
            gimbal.POSITIONS = new_pos
            gimbal.save_positions()
            self.set_status("参数已保存")
        except Exception as e:
            self.set_status(f"保存失败: {e}")

    def pause_action(self):
        gimbal.request_stop()   # 请求停止移动
        self.set_status("暂停移动（电机停止）")
        print("暂停按钮被点击 - 电机停止请求已发送")

    def on_close(self):
        self.running = False
        self.destroy()
        if self.main_app:
            self.main_app.capture_win = None


# ===== 学习窗口（不变） =====
class LearnWindow(tk.Toplevel):
    def __init__(self, master, main_app):
        super().__init__(master)
        self.main_app = main_app
        self.title("盲文学习")
        self.geometry("600x400")
        self.configure(bg="#f0f0f0")
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        self.mode = 'initials'          # 'initials' 或 'finals'
        self.current_index = 0

        # ---- 显示区域 ----
        display_frame = tk.Frame(self, bg="#f0f0f0")
        display_frame.pack(pady=10)

        self.current_label = tk.Label(display_frame, text="当前：无", font=("Microsoft YaHei", 16), bg="#f0f0f0")
        self.current_label.pack()

        self.dots_label = tk.Label(display_frame, text="点形：", font=("Microsoft YaHei", 14), bg="#f0f0f0")
        self.dots_label.pack()

        self.progress_label = tk.Label(display_frame, text="进度：0/0", font=("Microsoft YaHei", 12), bg="#f0f0f0")
        self.progress_label.pack(pady=5)

        # ---- 模式切换按钮 ----
        mode_frame = tk.Frame(self, bg="#f0f0f0")
        mode_frame.pack(pady=10)

        btn_initials = tk.Button(mode_frame, text="声母", command=lambda: self.set_mode('initials'),
                                 bg="#4CAF50", fg="white", font=("Microsoft YaHei", 10), padx=12, pady=5)
        btn_initials.pack(side=tk.LEFT, padx=5)

        btn_finals = tk.Button(mode_frame, text="韵母", command=lambda: self.set_mode('finals'),
                               bg="#2196F3", fg="white", font=("Microsoft YaHei", 10), padx=12, pady=5)
        btn_finals.pack(side=tk.LEFT, padx=5)

        # ---- 手动浏览按钮 ----
        nav_frame = tk.Frame(self, bg="#f0f0f0")
        nav_frame.pack(pady=10)

        btn_prev = tk.Button(nav_frame, text="上一个", command=self.prev_item,
                             bg="#78909C", fg="white", font=("Microsoft YaHei", 10), padx=15, pady=5)
        btn_prev.pack(side=tk.LEFT, padx=5)

        btn_next = tk.Button(nav_frame, text="下一个", command=self.next_item,
                             bg="#78909C", fg="white", font=("Microsoft YaHei", 10), padx=15, pady=5)
        btn_next.pack(side=tk.LEFT, padx=5)

        # ---- 状态栏 ----
        self.status_label = tk.Label(self, text="就绪", font=("Microsoft YaHei", 10), bg="#f0f0f0")
        self.status_label.pack(pady=5)

        # ---- 初始化显示 ----
        try:
            _setup_gpio()
            print("盲文 GPIO 已初始化")
        except Exception as e:
            print(f"盲文 GPIO 初始化失败: {e}")
        self._update_display()

    # ---------- 获取当前列表 ----------
    def get_items(self):
        return initials if self.mode == 'initials' else finals

    # ---------- 更新显示并发送盲文 ----------
    def _update_display(self):
        items = self.get_items()
        if not items:
            self.current_label.config(text="当前：无")
            self.dots_label.config(text="点形：")
            self.progress_label.config(text="进度：0/0")
            self._send_braille(0, cell=0)
            self._send_braille(0, cell=1)
            return

        # 边界保护
        if self.current_index < 0:
            self.current_index = 0
        if self.current_index >= len(items):
            self.current_index = len(items) - 1

        pinyin = items[self.current_index]
        binary = pinyin_to_binary.get(pinyin, "000000")
        decimal = int(binary, 2)
        dots = "".join("●" if ch == "1" else "○" for ch in binary)
        mode_name = "声母" if self.mode == 'initials' else "韵母"

        self.current_label.config(text=f"{mode_name}：{pinyin}  ({self.current_index+1}/{len(items)})")
        self.dots_label.config(text=f"点形：{dots}  (0x{int(binary,2):02X})")
        self.progress_label.config(text=f"进度：{self.current_index+1}/{len(items)}")
        self.status_label.config(text=f"当前 {pinyin}")

        # 发送盲文（声母显示在第一个方，韵母显示在第二个方）
        cell = 0 if self.mode == 'initials' else 1
        # 先清空所有方（防止残留）
        self._send_braille(0, cell=0)
        self._send_braille(0, cell=1)
        if decimal > 0:
            self._send_braille(decimal, cell=cell)

    def _send_braille(self, decimal, cell=0):
        """内部函数，发送一个盲文字节到指定方（0或1）"""
        try:
            _send_single_braille(decimal, cell=cell)
        except Exception as e:
            print(f"盲文发送错误: {e}")

    # ---------- 操作函数 ----------
    def set_mode(self, mode):
        if mode == self.mode:
            self.current_index = 0      # 同一模式点击则回到第一个
        else:
            self.mode = mode
            self.current_index = 0
        self._update_display()
        self.status_label.config(text=f"切换到{'声母' if mode=='initials' else '韵母'}模式")

    def prev_item(self):
        items = self.get_items()
        if not items:
            return
        self.current_index -= 1
        if self.current_index < 0:
            self.current_index = len(items) - 1   # 循环到最后一个
        self._update_display()

    def next_item(self):
        items = self.get_items()
        if not items:
            return
        self.current_index += 1
        if self.current_index >= len(items):
            self.current_index = 0                # 循环到第一个
        self._update_display()

    def on_close(self):
        # 关闭窗口时清空盲文并释放 GPIO
        try:
            _send_single_braille(0, cell=0)
            _send_single_braille(0, cell=1)
            _cleanup_gpio()
            print("盲文 GPIO 已释放")
        except Exception as e:
            print(f"清理盲文 GPIO 时出错: {e}")
        self.destroy()
        if self.main_app:
            self.main_app.learn_win = None

# ===== 启动 =====
def run_gui():
    global main_app
    root = tk.Tk()
    app = MainApp(root)
    main_app = app   # 赋值给全局变量
    root.mainloop()
    return app

if __name__ == "__main__":
    run_gui()